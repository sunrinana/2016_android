package com.example.sunrin.sunrin1230;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * Created by Sunrin on 2015-12-30.
 */

@lombok.Data
@AllArgsConstructor
public class Data {
    private String imageUrl;
    private int height;
    private int width;
}







